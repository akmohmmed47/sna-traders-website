import supabase from './db-client.js';

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'sna-admin-authenticated';
function checkAdmin(req) {
  return req.headers['x-admin-token'] === ADMIN_TOKEN;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('hero_settings').select('*').eq('id', 1).single();
      if (error && error.code !== 'PGRST116') throw error;
      return res.status(200).json(data || null);
    }
    if (req.method === 'PUT') {
      if (!checkAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
      const { headline, tagline, subtext, cta1_text, cta2_text, background_image } = req.body;
      const patch = {};
      if (headline !== undefined) patch.headline = headline;
      if (tagline !== undefined) patch.tagline = tagline;
      if (subtext !== undefined) patch.subtext = subtext;
      if (cta1_text !== undefined) patch.cta1_text = cta1_text;
      if (cta2_text !== undefined) patch.cta2_text = cta2_text;
      if (background_image !== undefined) patch.background_image = background_image;
      patch.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('hero_settings').update(patch).eq('id', 1).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('hero_settings API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
