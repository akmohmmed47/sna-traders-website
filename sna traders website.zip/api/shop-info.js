import supabase from './db-client.js';

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'sna-admin-authenticated';
function checkAdmin(req) {
  return req.headers['x-admin-token'] === ADMIN_TOKEN;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('shop_info').select('*').eq('id', 1).single();
      if (error && error.code !== 'PGRST116') throw error;
      return res.status(200).json(data || null);
    }
    if (req.method === 'PUT') {
      if (!checkAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
      const { address, phone, whatsapp, whatsapp_display, email, hours, facebook, instagram } = req.body;
      const patch = {};
      if (address !== undefined) patch.address = address;
      if (phone !== undefined) patch.phone = phone;
      if (whatsapp !== undefined) patch.whatsapp = whatsapp;
      if (whatsapp_display !== undefined) patch.whatsapp_display = whatsapp_display;
      if (email !== undefined) patch.email = email;
      if (hours !== undefined) patch.hours = hours;
      if (facebook !== undefined) patch.facebook = facebook;
      if (instagram !== undefined) patch.instagram = instagram;
      patch.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('shop_info').update(patch).eq('id', 1).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('shop_info API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
