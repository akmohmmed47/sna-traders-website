import supabase from './db-client.js';

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'sna-admin-authenticated';

function checkAdmin(req) {
  const token = req.headers['x-admin-token'];
  return token === ADMIN_TOKEN;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { visible_only, featured, category } = req.query;
      let query = supabase.from('products').select('*').order('id', { ascending: true });
      if (visible_only === '1' || visible_only === 'true') query = query.eq('visible', true);
      if (featured === '1' || featured === 'true') query = query.eq('featured', true);
      if (category) query = query.eq('category', category);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (!checkAdmin(req)) return res.status(401).json({ error: 'Unauthorized: admin login required' });
    if (req.method === 'POST') {
      const { name, category, description, price_label, image_url, visible, featured } = req.body;
      if (!name) return res.status(400).json({ error: 'Product name is required' });
      const { data, error } = await supabase.from('products').insert({
        name, category: category || 'General', description: description || '',
        price_label: price_label || 'Wholesale price on request',
        image_url: image_url || '', visible: visible !== false, featured: featured === true,
      }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, name, category, description, price_label, image_url, visible, featured } = req.body;
      if (!id) return res.status(400).json({ error: 'Product id is required' });
      const patch = {};
      if (name !== undefined) patch.name = name;
      if (category !== undefined) patch.category = category;
      if (description !== undefined) patch.description = description;
      if (price_label !== undefined) patch.price_label = price_label;
      if (image_url !== undefined) patch.image_url = image_url;
      if (visible !== undefined) patch.visible = visible;
      if (featured !== undefined) patch.featured = featured;
      const { data, error } = await supabase.from('products').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query?.id;
      if (!id) return res.status(400).json({ error: 'Product id is required' });
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('products API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
