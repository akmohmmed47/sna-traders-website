import supabase from './db-client.js';

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'sna-admin-authenticated';
function checkAdmin(req) {
  return req.headers['x-admin-token'] === ADMIN_TOKEN;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      if (!checkAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
      const { data, error } = await supabase.from('enquiries').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { name, phone, message } = req.body;
      if (!name || !phone || !message) return res.status(400).json({ error: 'Name, phone and message are required' });
      const { data, error } = await supabase.from('enquiries').insert({ name, phone, message, is_read: false }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (!checkAdmin(req)) return res.status(401).json({ error: 'Unauthorized' });
    if (req.method === 'PUT') {
      const { id, is_read } = req.body;
      if (!id) return res.status(400).json({ error: 'Enquiry id is required' });
      const { data, error } = await supabase.from('enquiries').update({ is_read }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query?.id;
      if (!id) return res.status(400).json({ error: 'Enquiry id is required' });
      const { error } = await supabase.from('enquiries').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('enquiries API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
