const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'sna123';
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'sna-admin-authenticated';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { username, password } = req.body || {};
    if (username === ADMIN_USER && password === ADMIN_PASS) {
      return res.status(200).json({ ok: true, token: ADMIN_TOKEN, username: ADMIN_USER });
    }
    return res.status(401).json({ error: 'Invalid username or password' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
