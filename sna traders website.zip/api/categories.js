import supabase from './db-client.js';

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'sna-admin-authenticated';
function checkAdmin(req) {
  return req.headers['x-admin-token'] === ADMIN_TOKEN;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('categories').select('*').order('id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (!checkAdmin(req)) return res.status(401).json({ error: 'Unauthorized: admin login required' });
    if (req.method === 'POST') {
      const { name, description, icon, image_url } = req.body;
      if (!name) return res.status(400).json({ error: 'Category name is required' });
      const { data, error } = await supabase.from('categories').insert({
        name, description: description || '', icon: icon || 'Package', image_url: image_url || '',
      }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, name, description, icon, image_url } = req.body;
      if (!id) return res.status(400).json({ error: 'Category id is required' });
      const patch = {};
      if (name !== undefined) patch.name = name;
      if (description !== undefined) patch.description = description;
      if (icon !== undefined) patch.icon = icon;
      if (image_url !== undefined) patch.image_url = image_url;
      const { data, error } = await supabase.from('categories').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query?.id;
      if (!id) return res.status(400).json({ error: 'Category id is required' });
      const { error } = await supabase.from('categories').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('categories API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
