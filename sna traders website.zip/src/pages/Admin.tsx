import { useEffect, useState } from 'react';
import {
  LayoutDashboard, Package, LayoutGrid, Inbox, Store, Image as ImageIcon,
  LogOut, Menu, X, Plus, Pencil, Trash2, Eye, EyeOff, MessageCircle,
  CheckCheck, Search, ExternalLink, Loader2, Lock,
} from 'lucide-react';
import { adminHeaders } from '../lib/site';
import type { Product } from '../components/FeaturedProducts';
import type { Category } from '../components/Categories';

type Enquiry = { id: number; name: string; phone: string; message: string; is_read: boolean; created_at: string };
type Tab = 'overview' | 'products' | 'categories' | 'enquiries' | 'shop' | 'hero';

const TABS: { id: Tab; label: string; icon: typeof Package }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'products', label: 'Products', icon: Package },
  { id: 'categories', label: 'Categories', icon: LayoutGrid },
  { id: 'enquiries', label: 'Enquiries', icon: Inbox },
  { id: 'shop', label: 'Shop Info', icon: Store },
  { id: 'hero', label: 'Hero Banner', icon: ImageIcon },
];

const ICON_OPTIONS = ['PenLine', 'NotebookText', 'Briefcase', 'Palette', 'Layers', 'Backpack', 'Package'];

function authed() { return !!localStorage.getItem('sna_admin_token'); }

export default function Admin() {
  const [loggedIn, setLoggedIn] = useState(authed());
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginErr, setLoginErr] = useState('');
  const [logging, setLogging] = useState(false);

  const [tab, setTab] = useState<Tab>('overview');
  const [sidebar, setSidebar] = useState(false);
  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [shop, setShop] = useState<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [hero, setHero] = useState<any>(null);
  const [msg, setMsg] = useState('');
  const [search, setSearch] = useState('');

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [pForm, setPForm] = useState<any>({ id: null, name: '', category: '', description: '', price_label: 'Wholesale price on request', image_url: '', visible: true, featured: false });
  const [pEditing, setPEditing] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [cForm, setCForm] = useState<any>({ id: null, name: '', description: '', icon: 'Package', image_url: '' });
  const [cEditing, setCEditing] = useState(false);

  const refresh = async () => {
    setLoading(true);
    try {
      const h = adminHeaders();
      const [p, c, e, s, hz] = await Promise.all([
        fetch('/api/products').then((r) => r.json()).catch(() => []),
        fetch('/api/categories').then((r) => r.json()).catch(() => []),
        fetch('/api/enquiries', { headers: h }).then((r) => (r.ok ? r.json() : [])).catch(() => []),
        fetch('/api/shop-info').then((r) => r.json()).catch(() => null),
        fetch('/api/hero-settings').then((r) => r.json()).catch(() => null),
      ]);
      if (Array.isArray(p)) setProducts(p);
      if (Array.isArray(c)) setCategories(c);
      if (Array.isArray(e)) setEnquiries(e);
      if (s) setShop(s);
      if (hz) setHero(hz);
    } finally { setLoading(false); }
  };

  useEffect(() => { if (loggedIn) refresh(); }, [loggedIn]);

  const login = async (e: React.FormEvent) => {
    e.preventDefault(); setLoginErr(''); setLogging(true);
    try {
      const res = await fetch('/api/admin-auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      localStorage.setItem('sna_admin_token', data.token);
      setLoggedIn(true);
    } catch (err: unknown) { setLoginErr(err instanceof Error ? err.message : 'Login failed'); } finally { setLogging(false); }
  };

  const logout = () => { localStorage.removeItem('sna_admin_token'); setLoggedIn(false); };
  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(''), 3000); };

  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pForm.name.trim()) return flash('Product name required');
    const method = pEditing ? 'PUT' : 'POST';
    const res = await fetch('/api/products', { method, headers: adminHeaders(), body: JSON.stringify(pForm) });
    if (res.ok) { flash(pEditing ? 'Product updated' : 'Product added'); setPForm({ id: null, name: '', category: '', description: '', price_label: 'Wholesale price on request', image_url: '', visible: true, featured: false }); setPEditing(false); refresh(); }
    else flash('Save failed — are you logged in?');
  };
  const delProduct = async (id: number) => {
    if (!confirm('Delete this product?')) return;
    const res = await fetch('/api/products', { method: 'DELETE', headers: adminHeaders(), body: JSON.stringify({ id }) });
    if (res.ok) { flash('Product deleted'); refresh(); }
  };
  const toggleVisible = async (p: Product) => {
    const res = await fetch('/api/products', { method: 'PUT', headers: adminHeaders(), body: JSON.stringify({ id: p.id, visible: !p.visible }) });
    if (res.ok) refresh();
  };
  const toggleFeatured = async (p: Product) => {
    const res = await fetch('/api/products', { method: 'PUT', headers: adminHeaders(), body: JSON.stringify({ id: p.id, featured: !p.featured }) });
    if (res.ok) refresh();
  };

  const saveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cForm.name.trim()) return flash('Category name required');
    const method = cEditing ? 'PUT' : 'POST';
    const res = await fetch('/api/categories', { method, headers: adminHeaders(), body: JSON.stringify(cForm) });
    if (res.ok) { flash(cEditing ? 'Category updated' : 'Category added'); setCForm({ id: null, name: '', description: '', icon: 'Package', image_url: '' }); setCEditing(false); refresh(); }
    else flash('Save failed');
  };
  const delCategory = async (id: number) => {
    if (!confirm('Delete this category?')) return;
    const res = await fetch('/api/categories', { method: 'DELETE', headers: adminHeaders(), body: JSON.stringify({ id }) });
    if (res.ok) { flash('Category deleted'); refresh(); }
  };

  const markRead = async (id: number, is_read: boolean) => {
    const res = await fetch('/api/enquiries', { method: 'PUT', headers: adminHeaders(), body: JSON.stringify({ id, is_read }) });
    if (res.ok) refresh();
  };
  const delEnquiry = async (id: number) => {
    if (!confirm('Delete this enquiry?')) return;
    const res = await fetch('/api/enquiries', { method: 'DELETE', headers: adminHeaders(), body: JSON.stringify({ id }) });
    if (res.ok) { flash('Enquiry deleted'); refresh(); }
  };

  const saveShop = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/shop-info', { method: 'PUT', headers: adminHeaders(), body: JSON.stringify(shop) });
    if (res.ok) flash('Shop info updated — live on website instantly');
    else flash('Save failed');
  };
  const saveHero = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/hero-settings', { method: 'PUT', headers: adminHeaders(), body: JSON.stringify(hero) });
    if (res.ok) flash('Hero banner updated — live on website instantly');
    else flash('Save failed');
  };

  const unread = enquiries.filter((e) => !e.is_read).length;
  const filtered = products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()) || (p.category || '').toLowerCase().includes(search.toLowerCase()));

  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-navy flex items-center justify-center px-4 relative overflow-hidden">
        <div className="absolute inset-0 hero-grid-pattern opacity-60" />
        <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-navy flex items-center justify-center font-heading font-black text-gold text-xl">SNA</div>
          <h1 className="font-heading font-black text-navy text-2xl text-center mt-4">Admin Login</h1>
          <p className="text-slate-500 text-sm text-center mt-1">SNA Traders dashboard — authorised staff only</p>
          <form onSubmit={login} className="mt-6 space-y-4">
            <div>
              <label className="text-sm font-bold text-navy">Username</label>
              <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-gold focus:ring-2 focus:ring-gold/30" placeholder="admin" />
            </div>
            <div>
              <label className="text-sm font-bold text-navy">Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-gold focus:ring-2 focus:ring-gold/30" placeholder="••••••••" />
            </div>
            {loginErr && <p className="text-red-600 text-sm font-semibold">{loginErr}</p>}
            <button disabled={logging} className="w-full bg-navy hover:bg-navy-light disabled:opacity-60 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2">
              {logging ? <Loader2 size={18} className="animate-spin" /> : <Lock size={16} />} Sign In
            </button>
          </form>
          <p className="text-center text-xs text-slate-400 mt-4">Demo: admin / sna123</p>
          <a href="/" className="block text-center text-xs font-bold text-navy mt-2 hover:underline">Back to website</a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <aside className="hidden md:flex w-64 bg-navy text-white flex-col shrink-0 min-h-screen sticky top-0 h-screen">
        <div className="p-5 flex items-center gap-2.5 border-b border-white/10">
          <div className="w-10 h-10 rounded-xl bg-gold flex items-center justify-center font-heading font-black text-navy">SNA</div>
          <div className="leading-tight"><p className="font-heading font-extrabold">SNA Traders</p><p className="text-[10px] uppercase tracking-widest text-gold-light">Admin Panel</p></div>
        </div>
        <nav className="p-3 space-y-1 flex-1">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-colors ${tab === t.id ? 'bg-gold text-navy' : 'text-white/70 hover:bg-white/10 hover:text-white'}`}>
              <t.icon size={18} /> {t.label}
              {t.id === 'enquiries' && unread > 0 && <span className="ml-auto bg-wa text-white text-[11px] font-black px-2 py-0.5 rounded-full">{unread}</span>}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10 space-y-1">
          <a href="/" className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-bold text-white/70 hover:bg-white/10"><ExternalLink size={17} /> View Website</a>
          <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-bold text-red-300 hover:bg-red-500/20"><LogOut size={17} /> Logout</button>
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        <div className="md:hidden bg-navy text-white px-4 py-3.5 flex items-center justify-between sticky top-0 z-40">
          <div className="flex items-center gap-2"><div className="w-9 h-9 rounded-lg bg-gold flex items-center justify-center font-heading font-black text-navy text-sm">SNA</div><p className="font-heading font-extrabold text-sm">Admin Panel</p></div>
          <button onClick={() => setSidebar(!sidebar)} className="p-2 rounded-lg hover:bg-white/10">{sidebar ? <X size={22} /> : <Menu size={22} />}</button>
        </div>
        {sidebar && (
          <div className="md:hidden bg-navy-dark px-4 py-3 grid grid-cols-2 gap-2 sticky top-[64px] z-40 border-t border-white/10">
            {TABS.map((t) => (
              <button key={t.id} onClick={() => { setTab(t.id); setSidebar(false); }} className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold ${tab === t.id ? 'bg-gold text-navy' : 'bg-white/10 text-white'}`}>
                <t.icon size={15} /> {t.label}{t.id === 'enquiries' && unread > 0 ? ` (${unread})` : ''}
              </button>
            ))}
            <button onClick={logout} className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold bg-red-500/20 text-red-200"><LogOut size={15} /> Logout</button>
          </div>
        )}

        <main className="p-4 sm:p-8 max-w-6xl mx-auto">
          {msg && <div className="mb-4 bg-green-50 border border-green-200 text-green-800 text-sm font-bold px-4 py-3 rounded-xl">{msg}</div>}

          {tab === 'overview' && (
            <div>
              <h1 className="font-heading font-black text-navy text-2xl sm:text-3xl">Dashboard</h1>
              <p className="text-slate-500 text-sm mt-1">Welcome back — here is your shop at a glance.</p>
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { label: 'Total Products', value: products.length, icon: Package, bg: 'bg-navy', ic: '' },
                  { label: 'Total Categories', value: categories.length, icon: LayoutGrid, bg: 'bg-gold', ic: 'text-navy' },
                  { label: 'Enquiries Received', value: enquiries.length, icon: Inbox, bg: 'bg-wa', ic: '' },
                ].map((s) => (
                  <div key={s.label} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className={`p-3.5 rounded-2xl ${s.bg} text-white`}><s.icon size={26} className={s.ic} /></div>
                    <div><p className="font-heading font-black text-navy text-3xl leading-none">{loading ? '…' : s.value}</p><p className="text-slate-500 text-sm font-semibold mt-1">{s.label}</p></div>
                  </div>
                ))}
              </div>
              <div className="mt-6 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                <h2 className="font-heading font-extrabold text-navy">Latest enquiries {unread > 0 && <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full ml-2">{unread} unread</span>}</h2>
                <div className="mt-4 space-y-3">
                  {enquiries.slice(0, 5).map((e) => (
                    <div key={e.id} className={`rounded-xl p-4 border text-sm ${e.is_read ? 'bg-slate-50 border-slate-100' : 'bg-gold/10 border-gold/40'}`}>
                      <div className="flex items-center justify-between gap-2"><p className="font-bold text-navy">{e.name} <span className="font-normal text-slate-500">• {e.phone}</span></p><span className="text-xs text-slate-400">{new Date(e.created_at).toLocaleDateString()}</span></div>
                      <p className="text-slate-600 mt-1 line-clamp-2">{e.message}</p>
                    </div>
                  ))}
                  {enquiries.length === 0 && <p className="text-slate-400 text-sm">No enquiries yet — they will appear here when customers use the contact form.</p>}
                </div>
                <button onClick={() => setTab('enquiries')} className="mt-4 text-sm font-bold text-navy hover:underline">View all enquiries →</button>
              </div>
            </div>
          )}

          {tab === 'products' && (
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <h1 className="font-heading font-black text-navy text-2xl">Product Manager ({products.length})</h1>
                <div className="relative"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products..." className="pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm w-full sm:w-64 outline-none focus:border-gold" /></div>
              </div>
              <form onSubmit={saveProduct} className="mt-5 bg-white rounded-2xl p-5 sm:p-6 border border-slate-100 shadow-sm">
                <h2 className="font-heading font-extrabold text-navy">{pEditing ? 'Edit Product' : 'Add New Product'}</h2>
                <div className="mt-4 grid sm:grid-cols-2 gap-4">
                  <input value={pForm.name} onChange={(e) => setPForm({ ...pForm, name: e.target.value })} placeholder="Product name *" className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  <input value={pForm.category} onChange={(e) => setPForm({ ...pForm, category: e.target.value })} placeholder="Category (e.g. Pens & Pencils)" list="cat-list" className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  <datalist id="cat-list">{categories.map((c) => <option key={c.id} value={c.name} />)}</datalist>
                  <input value={pForm.price_label} onChange={(e) => setPForm({ ...pForm, price_label: e.target.value })} placeholder="Price / enquiry label" className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  <input value={pForm.image_url} onChange={(e) => setPForm({ ...pForm, image_url: e.target.value })} placeholder="Image URL (e.g. /images/product-pens.jpg)" className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  <textarea value={pForm.description} onChange={(e) => setPForm({ ...pForm, description: e.target.value })} placeholder="Description" rows={2} className="sm:col-span-2 rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold resize-none" />
                  <label className="flex items-center gap-2 text-sm font-semibold text-slate-600"><input type="checkbox" checked={pForm.visible} onChange={(e) => setPForm({ ...pForm, visible: e.target.checked })} className="w-4 h-4 accent-[#0A1F5C]" /> Show on website</label>
                  <label className="flex items-center gap-2 text-sm font-semibold text-slate-600"><input type="checkbox" checked={pForm.featured} onChange={(e) => setPForm({ ...pForm, featured: e.target.checked })} className="w-4 h-4 accent-[#D4A017]" /> Featured product</label>
                </div>
                <div className="mt-4 flex gap-2">
                  <button className="inline-flex items-center gap-2 bg-navy text-white text-sm font-bold px-5 py-2.5 rounded-xl hover:bg-navy-light"><Plus size={16} /> {pEditing ? 'Update Product' : 'Add Product'}</button>
                  {pEditing && <button type="button" onClick={() => { setPEditing(false); setPForm({ id: null, name: '', category: '', description: '', price_label: 'Wholesale price on request', image_url: '', visible: true, featured: false }); }} className="text-sm font-bold px-5 py-2.5 rounded-xl border border-slate-200">Cancel</button>}
                </div>
              </form>
              <div className="mt-5 grid gap-3">
                {filtered.map((p) => (
                  <div key={p.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {p.image_url ? <img src={p.image_url} alt="" className="w-14 h-14 rounded-xl object-cover bg-slate-100 shrink-0" /> : <div className="w-14 h-14 rounded-xl bg-navy/10 flex items-center justify-center shrink-0"><Package size={22} className="text-navy" /></div>}
                      <div className="min-w-0">
                        <p className="font-bold text-navy truncate">{p.name}</p>
                        <p className="text-xs text-slate-500">{p.category} • {p.price_label}</p>
                        <div className="flex gap-1.5 mt-1">
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${p.visible ? 'bg-green-100 text-green-700' : 'bg-slate-200 text-slate-500'}`}>{p.visible ? 'VISIBLE' : 'HIDDEN'}</span>
                          {p.featured && <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-gold/20 text-gold-dark">FEATURED</span>}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <button onClick={() => toggleVisible(p)} title={p.visible ? 'Hide from website' : 'Show on website'} className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-navy">{p.visible ? <Eye size={16} /> : <EyeOff size={16} />}</button>
                      <button onClick={() => toggleFeatured(p)} title="Toggle featured" className="px-3 rounded-xl bg-gold/15 hover:bg-gold/30 text-gold-dark text-xs font-black">★</button>
                      <button onClick={() => { setPForm({ id: p.id, name: p.name, category: p.category, description: p.description, price_label: p.price_label, image_url: p.image_url, visible: p.visible, featured: p.featured }); setPEditing(true); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="p-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700"><Pencil size={16} /></button>
                      <button onClick={() => delProduct(p.id)} className="p-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-600"><Trash2 size={16} /></button>
                    </div>
                  </div>
                ))}
                {filtered.length === 0 && <p className="text-slate-400 text-sm text-center py-8">No products found.</p>}
              </div>
            </div>
          )}

          {tab === 'categories' && (
            <div>
              <h1 className="font-heading font-black text-navy text-2xl">Category Manager ({categories.length})</h1>
              <form onSubmit={saveCategory} className="mt-5 bg-white rounded-2xl p-5 sm:p-6 border border-slate-100 shadow-sm">
                <h2 className="font-heading font-extrabold text-navy">{cEditing ? 'Edit Category' : 'Add New Category'}</h2>
                <div className="mt-4 grid sm:grid-cols-2 gap-4">
                  <input value={cForm.name} onChange={(e) => setCForm({ ...cForm, name: e.target.value })} placeholder="Category name *" className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  <select value={cForm.icon} onChange={(e) => setCForm({ ...cForm, icon: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold">
                    {ICON_OPTIONS.map((i) => <option key={i} value={i}>{i}</option>)}
                  </select>
                  <input value={cForm.image_url} onChange={(e) => setCForm({ ...cForm, image_url: e.target.value })} placeholder="Image URL (optional)" className="sm:col-span-2 rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  <textarea value={cForm.description} onChange={(e) => setCForm({ ...cForm, description: e.target.value })} placeholder="Description" rows={2} className="sm:col-span-2 rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold resize-none" />
                </div>
                <div className="mt-4 flex gap-2">
                  <button className="inline-flex items-center gap-2 bg-navy text-white text-sm font-bold px-5 py-2.5 rounded-xl hover:bg-navy-light"><Plus size={16} /> {cEditing ? 'Update Category' : 'Add Category'}</button>
                  {cEditing && <button type="button" onClick={() => { setCEditing(false); setCForm({ id: null, name: '', description: '', icon: 'Package', image_url: '' }); }} className="text-sm font-bold px-5 py-2.5 rounded-xl border border-slate-200">Cancel</button>}
                </div>
              </form>
              <div className="mt-5 grid sm:grid-cols-2 gap-3">
                {categories.map((c) => (
                  <div key={c.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-navy flex items-center justify-center text-gold-light font-black shrink-0">{c.name.charAt(0)}</div>
                    <div className="flex-1 min-w-0"><p className="font-bold text-navy truncate">{c.name}</p><p className="text-xs text-slate-500 truncate">{c.description || c.icon}</p></div>
                    <button onClick={() => { setCForm({ id: c.id, name: c.name, description: c.description, icon: c.icon, image_url: c.image_url }); setCEditing(true); }} className="p-2.5 rounded-xl bg-blue-50 text-blue-700"><Pencil size={16} /></button>
                    <button onClick={() => delCategory(c.id)} className="p-2.5 rounded-xl bg-red-50 text-red-600"><Trash2 size={16} /></button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'enquiries' && (
            <div>
              <h1 className="font-heading font-black text-navy text-2xl">Enquiry Inbox ({enquiries.length})</h1>
              <p className="text-slate-500 text-sm mt-1">Messages submitted via the website contact form.</p>
              <div className="mt-5 grid gap-3">
                {enquiries.map((e) => (
                  <div key={e.id} className={`bg-white rounded-2xl p-5 border shadow-sm ${e.is_read ? 'border-slate-100' : 'border-gold/50 ring-1 ring-gold/30'}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-bold text-navy">{e.name} {!e.is_read && <span className="text-[10px] bg-wa text-white font-black px-2 py-0.5 rounded-full ml-1">NEW</span>}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{e.phone} • {new Date(e.created_at).toLocaleString()}</p>
                      </div>
                      <div className="flex gap-1.5 shrink-0">
                        <a href={`https://wa.me/${e.phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Hi ${e.name}, this is SNA Traders — thanks for your enquiry!`)}`} target="_blank" rel="noreferrer" className="p-2.5 rounded-xl bg-wa/10 text-wa-dark hover:bg-wa hover:text-white transition-colors" title="Reply on WhatsApp"><MessageCircle size={16} /></a>
                        <button onClick={() => markRead(e.id, !e.is_read)} className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-navy" title={e.is_read ? 'Mark unread' : 'Mark read'}><CheckCheck size={16} /></button>
                        <button onClick={() => delEnquiry(e.id)} className="p-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-600"><Trash2 size={16} /></button>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 mt-3 bg-slate-50 rounded-xl p-3 leading-relaxed">{e.message}</p>
                  </div>
                ))}
                {enquiries.length === 0 && <p className="text-slate-400 text-sm text-center py-8">Inbox empty.</p>}
              </div>
            </div>
          )}

          {tab === 'shop' && shop && (
            <div>
              <h1 className="font-heading font-black text-navy text-2xl">Shop Info Editor</h1>
              <p className="text-slate-500 text-sm mt-1">Changes reflect live on the public website instantly.</p>
              <form onSubmit={saveShop} className="mt-5 bg-white rounded-2xl p-5 sm:p-6 border border-slate-100 shadow-sm grid sm:grid-cols-2 gap-4">
                {[['address', 'Shop Address'], ['phone', 'Phone Number'], ['whatsapp', 'WhatsApp Number (e.g. 94703030811)'], ['whatsapp_display', 'WhatsApp Display (e.g. 070 303 0811)'], ['email', 'Email'], ['hours', 'Opening Hours'], ['facebook', 'Facebook URL'], ['instagram', 'Instagram URL']].map(([k, label]) => (
                  <div key={k} className={k === 'address' ? 'sm:col-span-2' : ''}>
                    <label className="text-xs font-bold text-navy uppercase tracking-wide">{label}</label>
                    <input value={shop[k] || ''} onChange={(e) => setShop({ ...shop, [k]: e.target.value })} className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />
                  </div>
                ))}
                <div className="sm:col-span-2"><button className="bg-navy text-white text-sm font-bold px-6 py-3 rounded-xl hover:bg-navy-light">Save Shop Info</button></div>
              </form>
            </div>
          )}

          {tab === 'hero' && hero && (
            <div>
              <h1 className="font-heading font-black text-navy text-2xl">Banner / Hero Editor</h1>
              <p className="text-slate-500 text-sm mt-1">Change the homepage banner text — updates instantly.</p>
              <form onSubmit={saveHero} className="mt-5 bg-white rounded-2xl p-5 sm:p-6 border border-slate-100 shadow-sm grid gap-4">
                {[['headline', 'Hero Headline'], ['tagline', 'Tagline / Badge Text'], ['subtext', 'Subtext'], ['cta1_text', 'CTA Button 1 Text'], ['cta2_text', 'CTA Button 2 Text'], ['background_image', 'Background Image URL']].map(([k, label]) => (
                  <div key={k}>
                    <label className="text-xs font-bold text-navy uppercase tracking-wide">{label}</label>
                    {k === 'subtext' ? <textarea value={hero[k] || ''} onChange={(e) => setHero({ ...hero, [k]: e.target.value })} rows={2} className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold resize-none" />
                    : <input value={hero[k] || ''} onChange={(e) => setHero({ ...hero, [k]: e.target.value })} className="mt-1.5 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-gold" />}
                  </div>
                ))}
                <div><button className="bg-navy text-white text-sm font-bold px-6 py-3 rounded-xl hover:bg-navy-light">Save Hero Banner</button></div>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
