import { useEffect, useState } from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Categories, { type Category } from '../components/Categories';
import WhyChooseUs from '../components/WhyChooseUs';
import FeaturedProducts, { type Product } from '../components/FeaturedProducts';
import HowToOrder from '../components/HowToOrder';
import About from '../components/About';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import FloatingWhatsApp from '../components/FloatingWhatsApp';
import type { ShopInfo, HeroSettings } from '../lib/site';

export default function Home() {
  const [shop, setShop] = useState<ShopInfo | null>(null);
  const [hero, setHero] = useState<HeroSettings | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const [s, h, c, p] = await Promise.all([
          fetch('/api/shop-info').then((r) => (r.ok ? r.json() : null)).catch(() => null),
          fetch('/api/hero-settings').then((r) => (r.ok ? r.json() : null)).catch(() => null),
          fetch('/api/categories').then((r) => (r.ok ? r.json() : [])).catch(() => []),
          fetch('/api/products?visible_only=1').then((r) => (r.ok ? r.json() : [])).catch(() => []),
        ]);
        if (s) setShop(s);
        if (h) setHero(h);
        if (Array.isArray(c)) setCategories(c);
        if (Array.isArray(p)) setProducts(p);
      } catch (e) { console.error(e); }
    })();
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar shop={shop} />
      <main>
        <Hero hero={hero} shop={shop} />
        <Categories categories={categories} shop={shop} />
        <WhyChooseUs />
        <FeaturedProducts products={products} shop={shop} />
        <HowToOrder shop={shop} />
        <About />
        <Contact shop={shop} />
      </main>
      <Footer shop={shop} />
      <FloatingWhatsApp shop={shop} />
    </div>
  );
}
