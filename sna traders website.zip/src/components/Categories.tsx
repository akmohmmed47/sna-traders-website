import { PenLine, NotebookText, Briefcase, Palette, Layers, Backpack, Package, ArrowRight } from 'lucide-react';
import Reveal from './Reveal';
import { waLink, type ShopInfo } from '../lib/site';

const ICONS: Record<string, unknown> = { PenLine, NotebookText, Briefcase, Palette, Layers, Backpack, Package };

export type Category = { id: number; name: string; description: string; icon: string; image_url: string };

const FALLBACK: Category[] = [
  { id: 1, name: 'Pens & Pencils', description: 'Ball pens, gel pens, pencils & markers in bulk', icon: 'PenLine', image_url: '' },
  { id: 2, name: 'Notebooks & Files', description: 'Exercise books, files, folders & registers', icon: 'NotebookText', image_url: '' },
  { id: 3, name: 'Office Supplies', description: 'Staplers, tapes, clips, calculators & more', icon: 'Briefcase', image_url: '' },
  { id: 4, name: 'Art & Craft', description: 'Colours, brushes, papers & craft essentials', icon: 'Palette', image_url: '' },
  { id: 5, name: 'Paper Products', description: 'A4, photo copy, chart & speciality papers', icon: 'Layers', image_url: '' },
  { id: 6, name: 'School Essentials', description: 'Bags, bottles, geometry boxes & uniforms', icon: 'Backpack', image_url: '' },
];

export default function Categories({ categories, shop }: { categories: Category[]; shop: ShopInfo | null }) {
  const items = categories.length >= 6 ? categories.slice(0, 6) : categories.length > 0 ? [...categories, ...FALLBACK.slice(categories.length)].slice(0, 6) : FALLBACK;
  return (
    <section id="categories" className="py-16 sm:py-20 bg-slate-50 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="text-gold-dark font-bold text-xs uppercase tracking-[0.22em]">What we supply</p>
          <h2 className="font-heading font-black text-navy text-2xl sm:text-4xl mt-2">Product Categories</h2>
          <p className="text-slate-500 mt-3 text-sm sm:text-base">Six wholesale departments covering everything a retailer, school or office needs — all under one roof in Pettah.</p>
        </Reveal>
        <div className="mt-10 grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6">
          {items.map((c, i) => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const Icon = (ICONS[c.icon] || Briefcase) as any;
            return (
              <Reveal key={String(c.id ?? i)} delay={i * 0.06}>
                <a href={waLink(shop, `Hi SNA Traders, I'd like the wholesale price list for ${c.name}.`)} target="_blank" rel="noreferrer" className="card-hover group block bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                  {c.image_url ? (
                    <div className="h-28 sm:h-40 overflow-hidden"><img src={c.image_url} alt={c.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" /></div>
                  ) : (
                    <div className="h-28 sm:h-40 bg-gradient-to-br from-navy via-navy-light to-navy-dark flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 hero-grid-pattern opacity-50" />
                      <div className="w-14 h-14 sm:w-20 sm:h-20 rounded-2xl bg-gold flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300">
                        <Icon size={30} className="text-navy" />
                      </div>
                    </div>
                  )}
                  <div className="p-3.5 sm:p-5">
                    <h3 className="font-heading font-extrabold text-navy text-sm sm:text-lg leading-snug">{c.name}</h3>
                    <p className="hidden sm:block text-slate-500 text-sm mt-1 line-clamp-2">{c.description}</p>
                    <span className="mt-2 inline-flex items-center gap-1 text-wa-dark font-bold text-xs sm:text-sm">Get price <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" /></span>
                  </div>
                </a>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
