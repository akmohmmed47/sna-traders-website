import { MessageCircle } from 'lucide-react';
import { waLink, type ShopInfo } from '../lib/site';

export default function FloatingWhatsApp({ shop }: { shop: ShopInfo | null }) {
  return (
    <a
      href={waLink(shop, "Hi SNA Traders, I'd like to enquire about wholesale products.")}
      target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-50 group flex items-center gap-2"
    >
      <span className="hidden sm:block max-w-0 overflow-hidden group-hover:max-w-[220px] transition-all duration-300 whitespace-nowrap bg-white text-navy text-xs font-bold px-0 group-hover:px-4 py-2.5 rounded-full shadow-xl">Chat for wholesale prices</span>
      <span className="relative w-14 h-14 rounded-full bg-wa hover:bg-wa-dark text-white flex items-center justify-center shadow-2xl transition-transform group-hover:scale-110">
        <span className="absolute inset-0 rounded-full bg-wa animate-ping opacity-25" />
        <MessageCircle size={28} className="relative" />
      </span>
    </a>
  );
}
