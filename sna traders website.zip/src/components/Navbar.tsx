import { useEffect, useState } from 'react';
import { Menu, X, MessageCircle, Phone } from 'lucide-react';
import { DEFAULT_SHOP, waLink, DEFAULT_WA_MSG, type ShopInfo } from '../lib/site';

const LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'Products', href: '#products' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar({ shop }: { shop: ShopInfo | null }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const s = { ...DEFAULT_SHOP, ...(shop || {}) };

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all ${scrolled ? 'shadow-lg shadow-navy/20' : ''}`}>
      <div className="bg-navy-dark text-white/90 text-[11px] sm:text-xs">
        <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center justify-between gap-2">
          <p className="truncate">{s.address} &nbsp;•&nbsp; {s.hours}</p>
          <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="hidden sm:flex items-center gap-1.5 font-semibold hover:text-gold-light">
            <Phone size={12} /> {s.phone}
          </a>
        </div>
      </div>
      <nav className="bg-navy text-white border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <a href="#home" className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gold flex items-center justify-center font-heading font-black text-navy text-lg leading-none shadow-md">SNA</div>
            <div className="leading-tight">
              <p className="font-heading font-extrabold text-lg tracking-tight">SNA Traders</p>
              <p className="text-[10px] uppercase tracking-[0.18em] text-gold-light font-semibold">Wholesale Stationery</p>
            </div>
          </a>
          <div className="hidden md:flex items-center gap-7 text-sm font-semibold">
            {LINKS.map((l) => (
              <a key={l.label} href={l.href} className="text-white/85 hover:text-gold-light transition-colors">{l.label}</a>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <a
              href={waLink(shop, DEFAULT_WA_MSG)}
              target="_blank" rel="noreferrer"
              className="hidden sm:inline-flex items-center gap-2 bg-wa hover:bg-wa-dark text-white text-sm font-bold px-4 py-2.5 rounded-full transition-colors shadow-md"
            >
              <MessageCircle size={16} /> Order on WhatsApp
            </a>
            <button onClick={() => setOpen(!open)} className="md:hidden p-2 rounded-lg hover:bg-white/10" aria-label="Toggle menu">
              {open ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="md:hidden bg-navy-dark border-t border-white/10 px-4 py-4 space-y-1">
            {LINKS.map((l) => (
              <a key={l.label} href={l.href} onClick={() => setOpen(false)} className="block px-3 py-2.5 rounded-lg font-semibold text-white/90 hover:bg-white/10 hover:text-gold-light">{l.label}</a>
            ))}
            <a
              href={waLink(shop, DEFAULT_WA_MSG)}
              target="_blank" rel="noreferrer"
              className="mt-2 flex items-center justify-center gap-2 bg-wa text-white font-bold px-4 py-3 rounded-xl"
            >
              <MessageCircle size={18} /> Order on WhatsApp
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}
