import { Search, MessageCircle, Truck } from 'lucide-react';
import Reveal from './Reveal';
import { waLink, DEFAULT_WA_MSG, type ShopInfo } from '../lib/site';

const STEPS = [
  { icon: Search, step: 'Step 1', title: 'Browse Products', desc: 'Explore categories & best sellers, note the items and quantities you need.' },
  { icon: MessageCircle, step: 'Step 2', title: 'WhatsApp Your Order', desc: 'Send your list on WhatsApp and get an instant wholesale quotation.' },
  { icon: Truck, step: 'Step 3', title: 'We Deliver', desc: 'Confirm your order and we pack & dispatch — Colombo or island-wide.' },
];

export default function HowToOrder({ shop }: { shop: ShopInfo | null }) {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="text-gold-dark font-bold text-xs uppercase tracking-[0.22em]">Simple & fast</p>
          <h2 className="font-heading font-black text-navy text-2xl sm:text-4xl mt-2">How to Order — 3 Steps</h2>
        </Reveal>
        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 relative">
          <div className="hidden md:block absolute top-12 left-[18%] right-[18%] h-0.5 bg-gradient-to-r from-gold via-gold to-gold opacity-40" />
          {STEPS.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.1}>
              <div className="relative text-center bg-slate-50 rounded-2xl p-7 border border-slate-100 card-hover">
                <div className="mx-auto w-16 h-16 rounded-2xl bg-navy flex items-center justify-center shadow-lg relative z-10">
                  <s.icon size={28} className="text-gold" />
                  <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-gold text-navy text-xs font-black flex items-center justify-center">{i + 1}</span>
                </div>
                <p className="text-gold-dark font-bold text-xs uppercase tracking-[0.2em] mt-4">{s.step}</p>
                <h3 className="font-heading font-extrabold text-navy text-xl mt-1">{s.title}</h3>
                <p className="text-slate-500 text-sm mt-2 leading-relaxed">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="text-center mt-8">
          <a href={waLink(shop, DEFAULT_WA_MSG)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-navy hover:bg-navy-light text-white font-heading font-bold px-8 py-3.5 rounded-full transition-colors">
            <MessageCircle size={18} /> Start Your Order Now
          </a>
        </Reveal>
      </div>
    </section>
  );
}
