import { Tags, LayoutGrid, Truck, ShieldCheck } from 'lucide-react';
import Reveal from './Reveal';

const FEATURES = [
  { icon: Tags, title: 'Wholesale Pricing', desc: 'Genuine bulk rates with tiered discounts on cartons and repeat orders.' },
  { icon: LayoutGrid, title: 'Wide Product Range', desc: '1000+ SKUs across pens, paper, office, art and school essentials.' },
  { icon: Truck, title: 'Island-wide Delivery', desc: 'Same-day dispatch in Colombo, 2-3 day delivery across the island.' },
  { icon: ShieldCheck, title: 'Trusted Since Years', desc: 'A decade serving retailers, schools & institutions with honest dealing.' },
];

export default function WhyChooseUs() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="text-gold-dark font-bold text-xs uppercase tracking-[0.22em]">Why choose us</p>
          <h2 className="font-heading font-black text-navy text-2xl sm:text-4xl mt-2">Why Choose SNA Traders</h2>
          <p className="text-slate-500 mt-3 text-sm sm:text-base">The wholesale partner hundreds of Sri Lankan retailers rely on every week.</p>
        </Reveal>
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.08}>
              <div className="card-hover h-full bg-slate-50 hover:bg-navy rounded-2xl p-6 border border-slate-100 group transition-colors duration-300">
                <div className="w-12 h-12 rounded-xl bg-navy group-hover:bg-gold flex items-center justify-center transition-colors duration-300">
                  <f.icon size={22} className="text-gold-light group-hover:text-navy transition-colors duration-300" />
                </div>
                <h3 className="font-heading font-extrabold text-navy group-hover:text-white text-lg mt-4 transition-colors duration-300">{f.title}</h3>
                <p className="text-slate-500 group-hover:text-white/70 text-sm mt-2 leading-relaxed transition-colors duration-300">{f.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
