import { MessageCircle, Eye } from 'lucide-react';
import Reveal from './Reveal';
import { waLink, type ShopInfo } from '../lib/site';

export type Product = {
  id: number; name: string; category: string; description: string;
  price_label: string; image_url: string; visible: boolean; featured: boolean;
};

const FALLBACK: Product[] = [
  { id: 101, name: 'Ball Pens (Box of 50)', category: 'Pens & Pencils', description: 'Smooth-write blue & black ball pens, bulk box.', price_label: 'Wholesale price on request', image_url: '/images/product-pens.jpg', visible: true, featured: true },
  { id: 102, name: 'A4 Exercise Books 80pg', category: 'Notebooks & Files', description: 'Single rule & square rule, carton of 100.', price_label: 'Wholesale price on request', image_url: '/images/product-notebooks.jpg', visible: true, featured: true },
  { id: 103, name: 'Office File Set', category: 'Office Supplies', description: 'Box files, clear folders & document cases.', price_label: 'Wholesale price on request', image_url: '/images/product-office.jpg', visible: true, featured: true },
  { id: 104, name: 'Art & Colour Kit', category: 'Art & Craft', description: 'Crayons, watercolours, brushes & craft paper.', price_label: 'Wholesale price on request', image_url: '/images/product-art.jpg', visible: true, featured: true },
  { id: 105, name: 'A4 Photocopy Paper', category: 'Paper Products', description: '80gsm premium white, 5-ream bundle.', price_label: 'Wholesale price on request', image_url: '/images/product-paper.jpg', visible: true, featured: true },
  { id: 106, name: 'School Essentials Pack', category: 'School Essentials', description: 'Bags, bottles, geometry boxes & more.', price_label: 'Wholesale price on request', image_url: '/images/product-school.jpg', visible: true, featured: true },
];

export default function FeaturedProducts({ products, shop }: { products: Product[]; shop: ShopInfo | null }) {
  const visible = products.filter((p) => p.visible);
  const list = visible.length >= 6 ? visible.slice(0, 6) : visible.length > 0 ? [...visible, ...FALLBACK.slice(visible.length)].slice(0, 6) : FALLBACK;
  return (
    <section id="products" className="py-16 sm:py-20 bg-navy relative overflow-hidden scroll-mt-24">
      <div className="absolute inset-0 hero-grid-pattern opacity-40" />
      <div className="relative max-w-7xl mx-auto px-4">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="text-gold font-bold text-xs uppercase tracking-[0.22em]">Best sellers</p>
          <h2 className="font-heading font-black text-white text-2xl sm:text-4xl mt-2">Featured Products</h2>
          <p className="text-white/60 mt-3 text-sm sm:text-base">High-turnover lines our retail partners reorder every week. Tap enquire for instant wholesale rates.</p>
        </Reveal>
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {list.map((p, i) => (
            <Reveal key={String(p.id ?? i)} delay={(i % 3) * 0.08}>
              <div className="card-hover bg-white rounded-2xl overflow-hidden flex flex-col h-full">
                <div className="relative h-48 sm:h-52 overflow-hidden bg-slate-100">
                  <img src={p.image_url} alt={p.name} loading="lazy" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = '/images/product-pens.jpg'; }} />
                  <span className="absolute top-3 left-3 bg-navy text-gold-light text-[11px] font-bold px-3 py-1 rounded-full">{p.category}</span>
                </div>
                <div className="p-5 flex flex-col flex-1">
                  <h3 className="font-heading font-extrabold text-navy text-lg leading-snug">{p.name}</h3>
                  <p className="text-slate-500 text-sm mt-1.5 line-clamp-2 flex-1">{p.description}</p>
                  <p className="text-gold-dark font-bold text-xs mt-2 uppercase tracking-wide flex items-center gap-1.5"><Eye size={13} /> {p.price_label || 'Wholesale price on request'}</p>
                  <a href={waLink(shop, `Hi SNA Traders, I'd like to enquire about "${p.name}" (${p.category}) wholesale price.`)} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center justify-center gap-2 bg-wa hover:bg-wa-dark text-white font-bold text-sm py-3 rounded-xl transition-colors">
                    <MessageCircle size={16} /> Enquire on WhatsApp
                  </a>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
