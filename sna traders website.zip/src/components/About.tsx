import { Award, Store, Users, CheckCircle2 } from 'lucide-react';
import Reveal from './Reveal';

export default function About() {
  return (
    <section id="about" className="py-16 sm:py-20 bg-slate-50 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 grid lg:grid-cols-2 gap-10 items-center">
        <Reveal>
          <div className="relative">
            <img src="/images/shop.jpg" alt="SNA Traders wholesale store" loading="lazy" className="rounded-2xl shadow-2xl w-full h-72 sm:h-96 object-cover" onError={(e) => { (e.target as HTMLImageElement).src = '/images/hero-stationery.jpg'; }} />
            <div className="absolute -bottom-5 left-5 right-5 sm:right-auto bg-navy text-white rounded-2xl px-6 py-4 shadow-xl flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gold flex items-center justify-center shrink-0"><Award size={24} className="text-navy" /></div>
              <div><p className="font-heading font-black text-2xl text-gold leading-none">10+ Years</p><p className="text-white/70 text-xs mt-1">Serving retailers across Sri Lanka</p></div>
            </div>
          </div>
        </Reveal>
        <Reveal delay={0.12}>
          <p className="text-gold-dark font-bold text-xs uppercase tracking-[0.22em]">About SNA Traders</p>
          <h2 className="font-heading font-black text-navy text-2xl sm:text-4xl mt-2 leading-tight">Colombo's wholesale partner for stationery retail</h2>
          <p className="text-slate-600 mt-4 leading-relaxed text-sm sm:text-base">
            SNA Traders is a leading stationery wholesaler based in Colombo, supplying retailers, schools, and businesses across Sri Lanka with quality products at competitive wholesale prices.
          </p>
          <p className="text-slate-600 mt-3 leading-relaxed text-sm sm:text-base">
            From our store at New Moor Street, Colombo 12 — in the heart of the Pettah wholesale district — we stock over a thousand lines across pens, notebooks, office supplies, art materials and school essentials, with honest dealing and fast island-wide dispatch.
          </p>
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { icon: Store, t: 'Pettah Store', d: 'Walk-in wholesale counter' },
              { icon: Users, t: '500+ Partners', d: 'Retailers & institutions' },
              { icon: CheckCircle2, t: 'Genuine Stock', d: 'Quality-checked lines' },
            ].map((b) => (
              <div key={b.t} className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm">
                <b.icon size={20} className="text-gold-dark" />
                <p className="font-bold text-navy text-sm mt-2">{b.t}</p>
                <p className="text-slate-500 text-xs">{b.d}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
