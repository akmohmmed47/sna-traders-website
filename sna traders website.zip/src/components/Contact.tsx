import { useState } from 'react';
import { MapPin, Phone, MessageCircle, Mail, Clock, Send, Loader2, CheckCircle2 } from 'lucide-react';
import Reveal from './Reveal';
import { DEFAULT_SHOP, waLink, type ShopInfo } from '../lib/site';

export default function Contact({ shop }: { shop: ShopInfo | null }) {
  const s = { ...DEFAULT_SHOP, ...(shop || {}) };
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!name.trim() || !phone.trim() || !message.trim()) { setError('Please fill in your name, phone and message.'); return; }
    setSending(true);
    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), phone: phone.trim(), message: message.trim() }),
      });
      if (!res.ok) throw new Error('Could not save enquiry');
      window.open(waLink(shop, `Hi SNA Traders! I'm ${name.trim()} (${phone.trim()}). ${message.trim()}`), '_blank');
      setDone(true); setName(''); setPhone(''); setMessage('');
      setTimeout(() => setDone(false), 6000);
    } catch {
      window.open(waLink(shop, `Hi SNA Traders! I'm ${name.trim()} (${phone.trim()}). ${message.trim()}`), '_blank');
      setDone(true);
    } finally { setSending(false); }
  };

  return (
    <section id="contact" className="py-16 sm:py-20 bg-white scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="text-gold-dark font-bold text-xs uppercase tracking-[0.22em]">Get in touch</p>
          <h2 className="font-heading font-black text-navy text-2xl sm:text-4xl mt-2">Contact SNA Traders</h2>
          <p className="text-slate-500 mt-3 text-sm sm:text-base">Visit our Pettah store, call us, or send your order list on WhatsApp — we reply fast.</p>
        </Reveal>
        <div className="mt-10 grid lg:grid-cols-2 gap-6">
          <Reveal>
            <div className="bg-navy rounded-2xl p-6 sm:p-8 text-white relative overflow-hidden h-full">
              <div className="absolute inset-0 hero-grid-pattern opacity-50" />
              <div className="relative space-y-5">
                <div className="flex gap-3.5"><div className="w-11 h-11 rounded-xl bg-gold flex items-center justify-center shrink-0"><MapPin size={20} className="text-navy" /></div><div><p className="text-gold-light text-xs font-bold uppercase tracking-widest">Visit us</p><p className="font-bold mt-0.5">{s.address}</p></div></div>
                <div className="flex gap-3.5"><div className="w-11 h-11 rounded-xl bg-gold flex items-center justify-center shrink-0"><Phone size={20} className="text-navy" /></div><div><p className="text-gold-light text-xs font-bold uppercase tracking-widest">Call us</p><a href={`tel:${s.phone.replace(/\s/g, '')}`} className="font-bold mt-0.5 hover:text-gold-light">{s.phone}</a></div></div>
                <div className="flex gap-3.5"><div className="w-11 h-11 rounded-xl bg-wa flex items-center justify-center shrink-0"><MessageCircle size={20} className="text-white" /></div><div><p className="text-gold-light text-xs font-bold uppercase tracking-widest">WhatsApp</p><a href={waLink(shop, "Hi SNA Traders, I'd like to enquire about wholesale products.")} target="_blank" rel="noreferrer" className="font-bold mt-0.5 hover:text-gold-light">{s.whatsapp_display}</a></div></div>
                <div className="flex gap-3.5"><div className="w-11 h-11 rounded-xl bg-gold flex items-center justify-center shrink-0"><Mail size={20} className="text-navy" /></div><div><p className="text-gold-light text-xs font-bold uppercase tracking-widest">Email</p><p className="font-bold mt-0.5 break-all">{s.email}</p></div></div>
                <div className="flex gap-3.5"><div className="w-11 h-11 rounded-xl bg-gold flex items-center justify-center shrink-0"><Clock size={20} className="text-navy" /></div><div><p className="text-gold-light text-xs font-bold uppercase tracking-widest">Hours</p><p className="font-bold mt-0.5">{s.hours}</p></div></div>
                <a href={waLink(shop, "Hi SNA Traders, I'd like to enquire about wholesale products.")} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 bg-wa hover:bg-wa-dark font-bold py-3.5 rounded-xl transition-colors">
                  <MessageCircle size={18} /> WhatsApp Us Now
                </a>
              </div>
            </div>
          </Reveal>
          <div className="space-y-6">
            <Reveal delay={0.1}>
              <form onSubmit={submit} className="bg-slate-50 rounded-2xl p-6 sm:p-8 border border-slate-100">
                <h3 className="font-heading font-extrabold text-navy text-xl">Send an Enquiry</h3>
                <p className="text-slate-500 text-sm mt-1">We save your enquiry and open WhatsApp to confirm instantly.</p>
                <div className="mt-5 space-y-4">
                  <div>
                    <label className="text-sm font-bold text-navy">Name *</label>
                    <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name / shop name" className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-gold focus:ring-2 focus:ring-gold/30" />
                  </div>
                  <div>
                    <label className="text-sm font-bold text-navy">Phone *</label>
                    <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="07X XXX XXXX" className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-gold focus:ring-2 focus:ring-gold/30" />
                  </div>
                  <div>
                    <label className="text-sm font-bold text-navy">Message *</label>
                    <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={4} placeholder="Tell us what you need — items, quantities, delivery city..." className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-gold focus:ring-2 focus:ring-gold/30 resize-none" />
                  </div>
                  {error && <p className="text-red-600 text-sm font-semibold">{error}</p>}
                  {done && <p className="flex items-center gap-1.5 text-wa-dark text-sm font-bold"><CheckCircle2 size={16} /> Enquiry received! We opened WhatsApp — just press send.</p>}
                  <button type="submit" disabled={sending} className="w-full inline-flex items-center justify-center gap-2 bg-wa hover:bg-wa-dark disabled:opacity-60 text-white font-bold py-3.5 rounded-xl transition-colors">
                    {sending ? <Loader2 size={18} className="animate-spin" /> : <Send size={17} />} Send via WhatsApp
                  </button>
                </div>
              </form>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-sm">
                <iframe
                  title="SNA Traders location — New Moor Street, Colombo 12"
                  src="https://www.google.com/maps?q=New+Moor+Street+Colombo+12+Pettah+Sri+Lanka&output=embed"
                  className="w-full h-64 sm:h-72"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
