import { motion } from 'framer-motion';
import { MessageCircle, ArrowDown, BadgeCheck, Truck, Tags } from 'lucide-react';
import { DEFAULT_HERO, DEFAULT_WA_MSG, waLink, type HeroSettings, type ShopInfo } from '../lib/site';

export default function Hero({ hero, shop }: { hero: HeroSettings | null; shop: ShopInfo | null }) {
  const h = { ...DEFAULT_HERO, ...(hero || {}) };
  return (
    <section id="home" className="relative bg-navy overflow-hidden pt-[104px]">
      <div className="absolute inset-0">
        <img src={h.background_image} alt="Stationery products flatlay" className="w-full h-full object-cover opacity-40" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/90 to-navy/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy via-transparent to-navy/60" />
        <div className="absolute inset-0 hero-grid-pattern opacity-60" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 py-16 sm:py-24 lg:py-28 grid lg:grid-cols-[1.2fr_0.8fr] gap-10 items-center">
        <div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="inline-flex items-center gap-2 bg-gold/15 border border-gold/40 text-gold-light text-xs sm:text-sm font-semibold px-4 py-1.5 rounded-full mb-5">
            <BadgeCheck size={15} /> {h.tagline}
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="font-heading font-black text-white text-3xl sm:text-5xl lg:text-[3.4rem] leading-[1.08] tracking-tight">
            {h.headline.split('Wholesale')[0]}
            {h.headline.includes('Wholesale') ? (<><span className="text-gold">Wholesale</span>{h.headline.split('Wholesale')[1]}</>) : h.headline}
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }} className="mt-4 text-white/80 text-base sm:text-lg max-w-xl">
            {h.subtext}
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }} className="mt-7 flex flex-wrap gap-3">
            <a href="#contact" className="inline-flex items-center gap-2 bg-gold hover:bg-gold-light text-navy font-heading font-extrabold text-sm sm:text-base px-6 py-3.5 rounded-full shadow-lg shadow-gold/25 transition-all">
              <Tags size={17} /> {h.cta1_text}
            </a>
            <a href="#products" className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/30 text-white font-heading font-bold text-sm sm:text-base px-6 py-3.5 rounded-full backdrop-blur transition-all">
              <ArrowDown size={17} /> {h.cta2_text}
            </a>
            <a href={waLink(shop, DEFAULT_WA_MSG)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-wa hover:bg-wa-dark text-white font-heading font-bold text-sm sm:text-base px-6 py-3.5 rounded-full shadow-lg transition-all">
              <MessageCircle size={17} /> WhatsApp Us Now
            </a>
          </motion.div>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-white/70 text-xs sm:text-sm font-medium">
            <span className="flex items-center gap-1.5">Genuine wholesale rates</span>
            <span className="flex items-center gap-1.5">1000+ products in stock</span>
            <span className="flex items-center gap-1.5">Island-wide delivery</span>
          </motion.div>
        </div>
        <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.25 }} className="hidden lg:block">
          <div className="bg-white rounded-2xl p-6 shadow-2xl">
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-gold-dark">Why retailers choose us</p>
            <h3 className="font-heading font-extrabold text-navy text-2xl mt-1">Bulk stock, ready to dispatch</h3>
            <div className="mt-4 space-y-3">
              {[
                { icon: Tags, t: 'True wholesale pricing', d: 'Tiered rates for cartons & bulk lots' },
                { icon: BadgeCheck, t: 'Quality you can trust', d: 'Genuine brands, checked before dispatch' },
                { icon: Truck, t: 'Fast island-wide delivery', d: 'Colombo same-day, island-wide 2-3 days' },
              ].map((r) => (
                <div key={r.t} className="flex gap-3 items-start bg-slate-50 rounded-xl p-3">
                  <div className="w-10 h-10 rounded-lg bg-navy text-gold-light flex items-center justify-center shrink-0"><r.icon size={19} /></div>
                  <div><p className="font-bold text-navy text-sm">{r.t}</p><p className="text-xs text-slate-500">{r.d}</p></div>
                </div>
              ))}
            </div>
            <a href={waLink(shop, DEFAULT_WA_MSG)} target="_blank" rel="noreferrer" className="mt-5 flex items-center justify-center gap-2 bg-wa hover:bg-wa-dark text-white font-bold py-3 rounded-xl transition-colors">
              <MessageCircle size={18} /> Get Price List on WhatsApp
            </a>
          </div>
        </motion.div>
      </div>
      <div className="relative border-t border-white/10 bg-navy-dark/70 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          {[['1000+', 'Products in stock'], ['500+', 'Retailers served'], ['25+', 'Districts covered'], ['10+', 'Years of trust']].map(([n, l]) => (
            <div key={l}><p className="font-heading font-black text-gold text-xl sm:text-2xl">{n}</p><p className="text-white/60 text-[11px] sm:text-xs font-medium">{l}</p></div>
          ))}
        </div>
      </div>
    </section>
  );
}
