import { MessageCircle, Facebook, Instagram, MapPin, Phone, Mail } from 'lucide-react';
import { DEFAULT_SHOP, waLink, DEFAULT_WA_MSG, type ShopInfo } from '../lib/site';

export default function Footer({ shop }: { shop: ShopInfo | null }) {
  const s = { ...DEFAULT_SHOP, ...(shop || {}) };
  return (
    <footer className="bg-navy-dark text-white">
      <div className="max-w-7xl mx-auto px-4 py-12 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gold flex items-center justify-center font-heading font-black text-navy">SNA</div>
            <div className="leading-tight">
              <p className="font-heading font-extrabold text-lg">SNA Traders</p>
              <p className="text-[10px] uppercase tracking-[0.18em] text-gold-light font-semibold">Wholesale Stationery</p>
            </div>
          </div>
          <p className="text-white/60 text-sm mt-4 leading-relaxed">Sri Lanka's trusted stationery wholesale partner for retailers, schools & institutions.</p>
          <div className="flex gap-2.5 mt-4">
            <a href={waLink(shop, DEFAULT_WA_MSG)} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="w-9 h-9 rounded-full bg-wa flex items-center justify-center hover:bg-wa-dark transition-colors"><MessageCircle size={17} /></a>
            {s.facebook ? <a href={s.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-gold hover:text-navy transition-colors"><Facebook size={17} /></a> : null}
            {s.instagram ? <a href={s.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-gold hover:text-navy transition-colors"><Instagram size={17} /></a> : null}
          </div>
        </div>
        <div>
          <p className="font-heading font-extrabold text-gold-light uppercase text-xs tracking-[0.2em]">Quick Links</p>
          <ul className="mt-4 space-y-2.5 text-sm text-white/70">
            <li><a href="#home" className="hover:text-gold-light">Home</a></li>
            <li><a href="#categories" className="hover:text-gold-light">Product Categories</a></li>
            <li><a href="#products" className="hover:text-gold-light">Featured Products</a></li>
            <li><a href="#about" className="hover:text-gold-light">About Us</a></li>
            <li><a href="#contact" className="hover:text-gold-light">Contact</a></li>
          </ul>
        </div>
        <div>
          <p className="font-heading font-extrabold text-gold-light uppercase text-xs tracking-[0.2em]">Contact Info</p>
          <ul className="mt-4 space-y-3 text-sm text-white/70">
            <li className="flex gap-2"><MapPin size={16} className="shrink-0 mt-0.5 text-gold" /> {s.address}</li>
            <li className="flex gap-2"><Phone size={16} className="shrink-0 mt-0.5 text-gold" /> <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="hover:text-gold-light">{s.phone}</a></li>
            <li className="flex gap-2"><MessageCircle size={16} className="shrink-0 mt-0.5 text-gold" /> <a href={waLink(shop, DEFAULT_WA_MSG)} target="_blank" rel="noreferrer" className="hover:text-gold-light">WhatsApp: {s.whatsapp_display}</a></li>
            <li className="flex gap-2"><Mail size={16} className="shrink-0 mt-0.5 text-gold" /> {s.email}</li>
          </ul>
        </div>
        <div>
          <p className="font-heading font-extrabold text-gold-light uppercase text-xs tracking-[0.2em]">Order Easily</p>
          <p className="text-white/60 text-sm mt-4">Send your item list on WhatsApp and get a wholesale quotation within minutes.</p>
          <a href={waLink(shop, DEFAULT_WA_MSG)} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 bg-wa hover:bg-wa-dark text-white text-sm font-bold px-5 py-3 rounded-full transition-colors">
            <MessageCircle size={16} /> Order on WhatsApp
          </a>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-white/50">
          <p>© 2025 SNA Traders. All Rights Reserved.</p>
          <p>Stationery Wholesale • Colombo 12, Sri Lanka</p>
        </div>
      </div>
    </footer>
  );
}
