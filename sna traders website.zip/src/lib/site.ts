export type ShopInfo = {
  id?: number;
  address: string;
  phone: string;
  whatsapp: string;
  whatsapp_display: string;
  email: string;
  hours: string;
  facebook: string;
  instagram: string;
};

export type HeroSettings = {
  id?: number;
  headline: string;
  tagline: string;
  subtext: string;
  cta1_text: string;
  cta2_text: string;
  background_image: string;
};

export const DEFAULT_SHOP: ShopInfo = {
  address: 'No.47/1, New Moor Street, Colombo 12',
  phone: '011 303 0118',
  whatsapp: '94703030811',
  whatsapp_display: '070 303 0811',
  email: 'info@snatraders.lk',
  hours: 'Mon – Sat: 9:00 AM – 6:00 PM',
  facebook: '',
  instagram: '',
};

export const DEFAULT_HERO: HeroSettings = {
  headline: "Sri Lanka's Trusted Stationery Wholesale Partner",
  tagline: 'Your Trusted Stationery Wholesale Partner',
  subtext: 'Bulk orders for retailers, schools & institutions across Sri Lanka.',
  cta1_text: 'Get Wholesale Price',
  cta2_text: 'Browse Products',
  background_image: '/images/hero-stationery.jpg',
};

export function waLink(shop: Partial<ShopInfo> | null | undefined, message: string) {
  const num = shop?.whatsapp || DEFAULT_SHOP.whatsapp;
  return `https://wa.me/${num}?text=${encodeURIComponent(message)}`;
}

export const DEFAULT_WA_MSG = "Hi SNA Traders, I'd like to enquire about wholesale products.";

export function adminHeaders(): HeadersInit {
  const token = typeof localStorage !== 'undefined' ? localStorage.getItem('sna_admin_token') || '' : '';
  return { 'Content-Type': 'application/json', 'x-admin-token': token };
}
